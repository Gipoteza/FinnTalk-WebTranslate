"use strict";
(() => {
  // src/options/options.ts
  var DEFAULT_SETTINGS = {
    proxyUrl: "https://finntalk-webtranslate-production.up.railway.app",
    model: "gpt-4o-mini",
    requestsPerMinute: 20,
    qualityCheckEnabled: false,
    translationStyle: "\u043D\u0435\u0439\u0442\u0440\u0430\u043B\u044C\u043D\u044B\u0439",
    autoTranslate: false
  };
  function serializeSettings(settings) {
    return { ...settings };
  }
  function deserializeSettings(raw) {
    return {
      proxyUrl: typeof raw["proxyUrl"] === "string" ? raw["proxyUrl"] : DEFAULT_SETTINGS.proxyUrl,
      model: isGptModel(raw["model"]) ? raw["model"] : DEFAULT_SETTINGS.model,
      requestsPerMinute: typeof raw["requestsPerMinute"] === "number" ? raw["requestsPerMinute"] : DEFAULT_SETTINGS.requestsPerMinute,
      qualityCheckEnabled: typeof raw["qualityCheckEnabled"] === "boolean" ? raw["qualityCheckEnabled"] : DEFAULT_SETTINGS.qualityCheckEnabled,
      translationStyle: isTranslationStyle(raw["translationStyle"]) ? raw["translationStyle"] : DEFAULT_SETTINGS.translationStyle,
      autoTranslate: typeof raw["autoTranslate"] === "boolean" ? raw["autoTranslate"] : DEFAULT_SETTINGS.autoTranslate
    };
  }
  function isGptModel(value) {
    return value === "gpt-4o" || value === "gpt-4o-mini" || value === "gpt-3.5-turbo";
  }
  function isTranslationStyle(value) {
    return value === "\u0431\u0443\u043A\u0432\u0430\u043B\u044C\u043D\u044B\u0439" || value === "\u043B\u0438\u0442\u0435\u0440\u0430\u0442\u0443\u0440\u043D\u044B\u0439" || value === "\u043D\u0435\u0439\u0442\u0440\u0430\u043B\u044C\u043D\u044B\u0439";
  }
  function saveSettings(settings) {
    return new Promise((resolve) => {
      chrome.storage.local.set(serializeSettings(settings), () => resolve());
    });
  }
  function loadSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get(null, (raw) => {
        resolve(deserializeSettings(raw));
      });
    });
  }
  function initOptionsPage() {
    const proxyUrlInput = document.getElementById("proxy-url");
    const modelSelect = document.getElementById("model");
    const requestsPerMinuteInput = document.getElementById("requests-per-minute");
    const qualityCheckInput = document.getElementById("quality-check");
    const btnSave = document.getElementById("btn-save");
    const saveStatus = document.getElementById("save-status");
    loadSettings().then((settings) => {
      proxyUrlInput.value = settings.proxyUrl;
      modelSelect.value = settings.model;
      requestsPerMinuteInput.value = String(settings.requestsPerMinute);
      qualityCheckInput.checked = settings.qualityCheckEnabled;
    });
    btnSave.addEventListener("click", () => {
      const settings = {
        proxyUrl: proxyUrlInput.value.trim(),
        model: modelSelect.value,
        requestsPerMinute: parseInt(requestsPerMinuteInput.value, 10) || DEFAULT_SETTINGS.requestsPerMinute,
        qualityCheckEnabled: qualityCheckInput.checked
      };
      saveSettings(settings).then(() => {
        saveStatus.classList.remove("hidden");
        setTimeout(() => saveStatus.classList.add("hidden"), 2e3);
      });
    });
  }
  if (typeof document !== "undefined" && typeof chrome !== "undefined" && chrome.storage) {
    document.addEventListener("DOMContentLoaded", initOptionsPage);
  }
})();
