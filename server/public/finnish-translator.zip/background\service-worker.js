"use strict";
(() => {
  // src/background/api-client.ts
  var DEFAULT_PROXY_URL = "https://finntalk-webtranslate-production.up.railway.app";
  var ApiClient = class {
    constructor(proxyUrl = DEFAULT_PROXY_URL, model) {
      this.proxyUrl = proxyUrl || DEFAULT_PROXY_URL;
      this.model = model;
    }
    async detectTopic(text) {
      const response = await fetch(`${this.proxyUrl}/api/detect-topic`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, model: this.model })
      });
      if (!response.ok) {
        const error = new Error(`HTTP error ${response.status}`);
        error.code = response.status;
        throw error;
      }
      const data = await response.json();
      return data.choices[0].message.content;
    }
    async translateBlock(block, systemPrompt) {
      const response = await fetch(`${this.proxyUrl}/api/translate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: block, systemPrompt, model: this.model })
      });
      if (!response.ok) {
        const error = new Error(`HTTP error ${response.status}`);
        error.code = response.status;
        throw error;
      }
      const data = await response.json();
      return data.choices[0].message.content;
    }
    async qualityCheck(original, translated) {
      const response = await fetch(`${this.proxyUrl}/api/quality-check`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ original, translated, model: this.model })
      });
      if (!response.ok) {
        const error = new Error(`HTTP error ${response.status}`);
        error.code = response.status;
        throw error;
      }
      const data = await response.json();
      return data.choices[0].message.content;
    }
  };

  // src/background/queue.ts
  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  var RequestQueue = class {
    constructor() {
      this._paused = false;
      this._pauseUntil = 0;
    }
    async enqueue(request) {
      if (this._paused) {
        const remaining = this._pauseUntil - Date.now();
        if (remaining > 0) {
          await delay(remaining);
        }
        this._paused = false;
      }
      const delays = [1e3, 2e3, 4e3];
      let lastError;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          return await request();
        } catch (err) {
          lastError = err;
          if (err && err.code === 401) {
            throw err;
          }
          if (err && err.code === 429) {
            this.pause(6e4);
            await delay(6e4);
          } else {
            if (attempt < delays.length) {
              await delay(delays[attempt]);
            }
          }
        }
      }
      throw lastError;
    }
    pause(durationMs) {
      this._paused = true;
      this._pauseUntil = Date.now() + durationMs;
    }
    getStatus() {
      if (!this._paused) {
        return { paused: false, pauseRemainingMs: 0 };
      }
      const remaining = this._pauseUntil - Date.now();
      if (remaining <= 0) {
        this._paused = false;
        return { paused: false, pauseRemainingMs: 0 };
      }
      return { paused: true, pauseRemainingMs: remaining };
    }
  };

  // src/background/service-worker.ts
  var PROXY_URL = "https://finntalk-webtranslate-production.up.railway.app";
  var SYSTEM_PROMPT = "\u0422\u044B \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A \u0441 \u0444\u0438\u043D\u0441\u043A\u043E\u0433\u043E \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u0438\u0439 \u044F\u0437\u044B\u043A. \u041F\u0435\u0440\u0435\u0432\u043E\u0434\u0438 \u0442\u043E\u0447\u043D\u043E \u0438 \u0435\u0441\u0442\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u043E. \u0412\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0439 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0431\u0435\u0437 \u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0435\u0432.";
  function log(...args) {
    console.log("[FT]", ...args);
  }
  function logErr(...args) {
    console.error("[FT ERROR]", ...args);
  }
  async function loadSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get({
        proxyUrl: PROXY_URL,
        model: "gpt-4o-mini",
        requestsPerMinute: 20,
        qualityCheckEnabled: false,
        translationStyle: "\u043D\u0435\u0439\u0442\u0440\u0430\u043B\u044C\u043D\u044B\u0439",
        autoTranslate: false
      }, (result) => resolve(result));
    });
  }
  var queue = new RequestQueue();
  async function handleTranslatePage(tabId) {
    log("handleTranslatePage tabId=", tabId);
    const settings = await loadSettings();
    const client = new ApiClient(settings.proxyUrl || PROXY_URL, settings.model);
    log("sending EXTRACT_TEXT to tab", tabId);
    let rawText;
    let blocks;
    try {
      const extracted = await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, { type: "EXTRACT_TEXT" }, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else if (!response) {
            reject(new Error("Empty response from content script"));
          } else {
            resolve(response);
          }
        });
      });
      rawText = extracted.rawText;
      blocks = extracted.blocks;
      log("EXTRACT_TEXT ok, rawText.length=", rawText.length, "blocks=", blocks.length);
    } catch (err) {
      logErr("EXTRACT_TEXT failed:", err.message);
      chrome.runtime.sendMessage({
        type: "TRANSLATION_ERROR",
        message: "\u041F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 (F5) \u0438 \u043F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0441\u043D\u043E\u0432\u0430."
      });
      return;
    }
    if (!rawText || rawText.trim().length < 10) {
      logErr("rawText too short:", rawText?.length);
      chrome.runtime.sendMessage({ type: "TRANSLATION_ERROR", message: "\u041D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0442\u0435\u043A\u0441\u0442 \u0434\u043B\u044F \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430." });
      return;
    }
    chrome.runtime.sendMessage({ type: "PROGRESS_UPDATE", done: 0, total: 1, topic: "\u0431\u044B\u0442\u043E\u0432\u0430\u044F" });
    const textToTranslate = rawText.slice(0, 12e3);
    log("translating, length=", textToTranslate.length);
    let translatedText;
    try {
      translatedText = await queue.enqueue(() => client.translateBlock(textToTranslate, SYSTEM_PROMPT));
      log("translation ok, length=", translatedText.length, "preview=", translatedText.slice(0, 80));
    } catch (err) {
      logErr("translateBlock failed:", err.message, "code=", err.code);
      const msg = err.code === 401 ? "\u041E\u0448\u0438\u0431\u043A\u0430 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u0438. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 OPENAI_API_KEY \u043D\u0430 Railway." : err.code === 429 ? "\u041F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435." : `\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430: ${err.message}`;
      chrome.runtime.sendMessage({ type: "TRANSLATION_ERROR", message: msg, openOptions: err.code === 401 });
      return;
    }
    chrome.runtime.sendMessage({ type: "PROGRESS_UPDATE", done: 1, total: 1, topic: "\u0431\u044B\u0442\u043E\u0432\u0430\u044F" });
    log("sending APPLY_TRANSLATION to tab", tabId);
    try {
      await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, {
          type: "APPLY_TRANSLATION",
          translatedParts: [translatedText]
        }, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            log("APPLY_TRANSLATION response:", response);
            resolve();
          }
        });
      });
    } catch (err) {
      logErr("APPLY_TRANSLATION failed:", err.message);
      chrome.runtime.sendMessage({ type: "TRANSLATION_ERROR", message: "\u041F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 (F5) \u0438 \u043F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0441\u043D\u043E\u0432\u0430." });
      return;
    }
    log("translation complete");
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    log("onMessage:", message.type);
    if (message.type === "TRANSLATE_PAGE") {
      handleTranslatePage(message.tabId).catch((err) => {
        logErr("handleTranslatePage unhandled:", err);
      });
      sendResponse({ ok: true });
      return true;
    }
    if (message.type === "TOGGLE_AUTO_TRANSLATE") {
      chrome.storage.local.set({ autoTranslate: message.enabled }, () => sendResponse({ ok: true }));
      return true;
    }
    if (message.type === "CHANGE_STYLE") {
      chrome.storage.local.set({ translationStyle: message.style }, () => sendResponse({ ok: true }));
      return true;
    }
    return false;
  });
  log("service worker loaded");
})();
