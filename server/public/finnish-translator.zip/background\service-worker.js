"use strict";
(() => {
  // src/background/api-client.ts
  var DEFAULT_PROXY_URL = "https://finntalk-webtranslate-production.up.railway.app";
  var ApiClient = class {
    constructor(proxyUrl = DEFAULT_PROXY_URL, model) {
      this.proxyUrl = proxyUrl || DEFAULT_PROXY_URL;
      this.model = model;
    }
    async detectTopic(text) {
      const response = await fetch(`${this.proxyUrl}/api/detect-topic`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, model: this.model })
      });
      if (!response.ok) {
        const error = new Error(`HTTP error ${response.status}`);
        error.code = response.status;
        throw error;
      }
      const data = await response.json();
      return data.choices[0].message.content;
    }
    async translateBlock(block, systemPrompt) {
      const response = await fetch(`${this.proxyUrl}/api/translate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: block, systemPrompt, model: this.model })
      });
      if (!response.ok) {
        const error = new Error(`HTTP error ${response.status}`);
        error.code = response.status;
        throw error;
      }
      const data = await response.json();
      return data.choices[0].message.content;
    }
    async qualityCheck(original, translated) {
      const response = await fetch(`${this.proxyUrl}/api/quality-check`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ original, translated, model: this.model })
      });
      if (!response.ok) {
        const error = new Error(`HTTP error ${response.status}`);
        error.code = response.status;
        throw error;
      }
      const data = await response.json();
      return data.choices[0].message.content;
    }
  };

  // src/background/queue.ts
  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  var RequestQueue = class {
    constructor() {
      this._paused = false;
      this._pauseUntil = 0;
    }
    async enqueue(request) {
      if (this._paused) {
        const remaining = this._pauseUntil - Date.now();
        if (remaining > 0) {
          await delay(remaining);
        }
        this._paused = false;
      }
      const delays = [1e3, 2e3, 4e3];
      let lastError;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          return await request();
        } catch (err) {
          lastError = err;
          if (err && err.code === 401) {
            throw err;
          }
          if (err && err.code === 429) {
            this.pause(6e4);
            await delay(6e4);
          } else {
            if (attempt < delays.length) {
              await delay(delays[attempt]);
            }
          }
        }
      }
      throw lastError;
    }
    pause(durationMs) {
      this._paused = true;
      this._pauseUntil = Date.now() + durationMs;
    }
    getStatus() {
      if (!this._paused) {
        return { paused: false, pauseRemainingMs: 0 };
      }
      const remaining = this._pauseUntil - Date.now();
      if (remaining <= 0) {
        this._paused = false;
        return { paused: false, pauseRemainingMs: 0 };
      }
      return { paused: true, pauseRemainingMs: remaining };
    }
  };

  // src/background/topic-detector.ts
  var VALID_TOPICS = [
    "\u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0430",
    "\u044E\u0440\u0438\u0441\u043F\u0440\u0443\u0434\u0435\u043D\u0446\u0438\u044F",
    "\u0444\u0438\u043D\u0430\u043D\u0441\u044B",
    "\u0442\u0435\u0445\u043D\u0438\u043A\u0430",
    "IT",
    "\u0431\u044B\u0442\u043E\u0432\u0430\u044F",
    "\u0434\u0435\u043B\u043E\u0432\u0430\u044F",
    "\u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u043D\u0430\u044F"
  ];
  var TOPIC_MAP = {
    "\u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0430": "\u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0430",
    "\u044E\u0440\u0438\u0441\u043F\u0440\u0443\u0434\u0435\u043D\u0446\u0438\u044F": "\u044E\u0440\u0438\u0441\u043F\u0440\u0443\u0434\u0435\u043D\u0446\u0438\u044F",
    "\u0444\u0438\u043D\u0430\u043D\u0441\u044B": "\u0444\u0438\u043D\u0430\u043D\u0441\u044B",
    "\u0442\u0435\u0445\u043D\u0438\u043A\u0430": "\u0442\u0435\u0445\u043D\u0438\u043A\u0430",
    "it": "IT",
    "IT": "IT",
    "\u0431\u044B\u0442\u043E\u0432\u0430\u044F": "\u0431\u044B\u0442\u043E\u0432\u0430\u044F",
    "\u0434\u0435\u043B\u043E\u0432\u0430\u044F": "\u0434\u0435\u043B\u043E\u0432\u0430\u044F",
    "\u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u043D\u0430\u044F": "\u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u043D\u0430\u044F"
  };
  function normalizeTopic(response) {
    const trimmed = response.trim();
    const lower = trimmed.toLowerCase();
    for (const [key, value] of Object.entries(TOPIC_MAP)) {
      if (key.toLowerCase() === lower) {
        return value;
      }
    }
    return "\u0431\u044B\u0442\u043E\u0432\u0430\u044F";
  }
  function buildSystemPrompt(topic, style) {
    const topicInstructions = {
      "\u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0430": "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u0443\u044E \u0442\u0435\u0440\u043C\u0438\u043D\u043E\u043B\u043E\u0433\u0438\u044E. \u0421\u043E\u0445\u0440\u0430\u043D\u044F\u0439 \u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u043A\u043B\u0438\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0442\u0435\u0440\u043C\u0438\u043D\u043E\u0432.",
      "\u044E\u0440\u0438\u0441\u043F\u0440\u0443\u0434\u0435\u043D\u0446\u0438\u044F": "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0442\u0435\u0440\u043C\u0438\u043D\u043E\u043B\u043E\u0433\u0438\u044E. \u0421\u043E\u0445\u0440\u0430\u043D\u044F\u0439 \u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u043F\u0440\u0430\u0432\u043E\u0432\u044B\u0445 \u0444\u043E\u0440\u043C\u0443\u043B\u0438\u0440\u043E\u0432\u043E\u043A.",
      "\u0444\u0438\u043D\u0430\u043D\u0441\u044B": "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u0443\u044E \u0442\u0435\u0440\u043C\u0438\u043D\u043E\u043B\u043E\u0433\u0438\u044E. \u0421\u043E\u0445\u0440\u0430\u043D\u044F\u0439 \u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u0447\u0438\u0441\u043B\u043E\u0432\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445.",
      "\u0442\u0435\u0445\u043D\u0438\u043A\u0430": "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 \u0442\u0435\u0445\u043D\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u0442\u0435\u0440\u043C\u0438\u043D\u043E\u043B\u043E\u0433\u0438\u044E. \u0421\u043E\u0445\u0440\u0430\u043D\u044F\u0439 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u0434\u0435\u0442\u0430\u043B\u0435\u0439 \u0438 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u043E\u0432.",
      "IT": "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 IT-\u0442\u0435\u0440\u043C\u0438\u043D\u043E\u043B\u043E\u0433\u0438\u044E. \u0422\u0435\u0445\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0442\u0435\u0440\u043C\u0438\u043D\u044B \u043C\u043E\u0436\u043D\u043E \u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0442\u044C \u043D\u0430 \u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u043E\u043C.",
      "\u0431\u044B\u0442\u043E\u0432\u0430\u044F": "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u043D\u044B\u0439 \u0441\u0442\u0438\u043B\u044C. \u041F\u0435\u0440\u0435\u0432\u043E\u0434 \u0434\u043E\u043B\u0436\u0435\u043D \u0437\u0432\u0443\u0447\u0430\u0442\u044C \u0435\u0441\u0442\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u043E.",
      "\u0434\u0435\u043B\u043E\u0432\u0430\u044F": "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 \u0434\u0435\u043B\u043E\u0432\u043E\u0439 \u0441\u0442\u0438\u043B\u044C. \u0421\u043E\u0445\u0440\u0430\u043D\u044F\u0439 \u0444\u043E\u0440\u043C\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0438 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u043E\u043D\u0430\u043B\u0438\u0437\u043C.",
      "\u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u043D\u0430\u044F": "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u043D\u044B\u0439 \u0441\u0442\u0438\u043B\u044C. \u041F\u0435\u0440\u0435\u0434\u0430\u0432\u0430\u0439 \u0438\u043D\u0442\u043E\u043D\u0430\u0446\u0438\u044E \u0438 \u044D\u043C\u043E\u0446\u0438\u0438."
    };
    const styleInstructions = {
      "\u0431\u0443\u043A\u0432\u0430\u043B\u044C\u043D\u044B\u0439": "\u041F\u0435\u0440\u0435\u0432\u043E\u0434\u0438 \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E \u0431\u043B\u0438\u0437\u043A\u043E \u043A \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u0443, \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044F \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0443 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0439.",
      "\u043B\u0438\u0442\u0435\u0440\u0430\u0442\u0443\u0440\u043D\u044B\u0439": "\u041F\u0435\u0440\u0435\u0432\u043E\u0434\u0438 \u0441\u0432\u043E\u0431\u043E\u0434\u043D\u043E, \u0430\u0434\u0430\u043F\u0442\u0438\u0440\u0443\u044F \u0442\u0435\u043A\u0441\u0442 \u0434\u043B\u044F \u0435\u0441\u0442\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u0437\u0432\u0443\u0447\u0430\u043D\u0438\u044F \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u043E\u043C.",
      "\u043D\u0435\u0439\u0442\u0440\u0430\u043B\u044C\u043D\u044B\u0439": "\u041F\u0435\u0440\u0435\u0432\u043E\u0434\u0438 \u0442\u043E\u0447\u043D\u043E, \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044F \u0441\u043C\u044B\u0441\u043B, \u0441 \u0435\u0441\u0442\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u043C \u0440\u0443\u0441\u0441\u043A\u0438\u043C \u044F\u0437\u044B\u043A\u043E\u043C."
    };
    return `\u0422\u044B \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A \u0441 \u0444\u0438\u043D\u0441\u043A\u043E\u0433\u043E \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u0438\u0439 \u044F\u0437\u044B\u043A.
${topicInstructions[topic]}
${styleInstructions[style]}
\u041F\u0435\u0440\u0435\u0432\u043E\u0434\u0438 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043D\u044B\u0439 \u0442\u0435\u043A\u0441\u0442. \u041D\u0435 \u0434\u043E\u0431\u0430\u0432\u043B\u044F\u0439 \u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0435\u0432 \u0438 \u043F\u043E\u044F\u0441\u043D\u0435\u043D\u0438\u0439.`;
  }

  // src/background/service-worker.ts
  function logError(requestId, code, message) {
    console.error(
      `[FinnishTranslator] ERROR ${(/* @__PURE__ */ new Date()).toISOString()} requestId=${requestId} code=${code} message=${message}`
    );
  }
  function getBlocksToProcess(blocks, currentIndex) {
    return blocks.slice(currentIndex);
  }
  async function loadSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get(
        {
          proxyUrl: "https://finntalk-webtranslate-production.up.railway.app",
          model: "gpt-4o-mini",
          requestsPerMinute: 20,
          qualityCheckEnabled: false,
          translationStyle: "\u043D\u0435\u0439\u0442\u0440\u0430\u043B\u044C\u043D\u044B\u0439",
          autoTranslate: false
        },
        (result) => resolve(result)
      );
    });
  }
  async function saveState(state) {
    return new Promise((resolve) => {
      chrome.storage.session.set({ translationState: state }, resolve);
    });
  }
  async function loadState(tabId) {
    return new Promise((resolve) => {
      chrome.storage.session.get("translationState", (result) => {
        const state = result.translationState;
        if (state && state.tabId === tabId) {
          resolve(state);
        } else {
          resolve(null);
        }
      });
    });
  }
  var queue = null;
  var apiClient = null;
  async function getQueueAndClient() {
    const settings = await loadSettings();
    if (!queue) {
      queue = new RequestQueue();
    }
    apiClient = new ApiClient(settings.proxyUrl, settings.model);
    return { queue, client: apiClient };
  }
  async function handleTranslatePage(tabId) {
    const requestId = `translate-${tabId}-${Date.now()}`;
    const settings = await loadSettings();
    if (!settings.proxyUrl) {
      chrome.runtime.sendMessage({
        type: "TRANSLATION_ERROR",
        message: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 URL Railway-\u043F\u0440\u043E\u043A\u0441\u0438 \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F.",
        openOptions: true
      });
      return;
    }
    const initialState = {
      tabId,
      topic: null,
      style: settings.translationStyle,
      blocks: [],
      currentBlockIndex: 0,
      status: "detecting"
    };
    await saveState(initialState);
    let extracted;
    try {
      extracted = await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, { type: "EXTRACT_TEXT" }, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(response);
          }
        });
      });
    } catch (err) {
      logError(requestId, "NETWORK", err.message ?? String(err));
      const isConnectionError = err.message?.includes("Could not establish connection") || err.message?.includes("Receiving end does not exist");
      chrome.runtime.sendMessage({
        type: "TRANSLATION_ERROR",
        message: isConnectionError ? "\u041F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 (F5) \u0438 \u043F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0441\u043D\u043E\u0432\u0430." : `\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u0442\u0435\u043A\u0441\u0442 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B: ${err.message}`
      });
      return;
    }
    const { rawText } = extracted;
    const { queue: q, client } = await getQueueAndClient();
    let topic;
    try {
      const sampleText = rawText.slice(0, 500);
      const rawTopic = await q.enqueue(() => client.detectTopic(sampleText));
      topic = normalizeTopic(rawTopic);
    } catch (err) {
      logError(requestId, err.code ?? "NETWORK", err.message ?? String(err));
      topic = "\u0431\u044B\u0442\u043E\u0432\u0430\u044F";
    }
    chrome.runtime.sendMessage({ type: "PROGRESS_UPDATE", done: 0, total: 1, topic });
    const systemPrompt = buildSystemPrompt(topic, settings.translationStyle);
    let translatedText;
    try {
      const textToTranslate = rawText.slice(0, 12e3);
      translatedText = await q.enqueue(() => client.translateBlock(textToTranslate, systemPrompt));
    } catch (err) {
      const code = err.code ?? "NETWORK";
      logError(requestId, code, err.message ?? String(err));
      if (err.code === 401) {
        chrome.runtime.sendMessage({ type: "TRANSLATION_ERROR", message: "\u041E\u0448\u0438\u0431\u043A\u0430 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u0438. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 OPENAI_API_KEY \u043D\u0430 Railway.", openOptions: true });
      } else if (err.code === 429) {
        chrome.runtime.sendMessage({ type: "TRANSLATION_ERROR", message: "\u041F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u043F\u043E\u0437\u0436\u0435." });
      } else {
        chrome.runtime.sendMessage({ type: "TRANSLATION_ERROR", message: `\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430: ${err.message}` });
      }
      return;
    }
    chrome.runtime.sendMessage({ type: "PROGRESS_UPDATE", done: 1, total: 1, topic });
    try {
      await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, {
          type: "APPLY_TRANSLATION",
          translatedParts: [translatedText]
        }, (response) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve();
        });
      });
    } catch (err) {
      logError(requestId, "APPLY", err.message ?? String(err));
      chrome.runtime.sendMessage({ type: "TRANSLATION_ERROR", message: "\u041F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 (F5) \u0438 \u043F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0441\u043D\u043E\u0432\u0430." });
      return;
    }
    const finalState = await loadState(tabId);
    if (finalState) await saveState({ ...finalState, status: "done" });
  }
  if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener(
      (message, _sender, sendResponse) => {
        if (message.type === "TRANSLATE_PAGE") {
          handleTranslatePage(message.tabId).catch((err) => {
            logError(`translate-${message.tabId}`, "UNHANDLED", String(err));
          });
          sendResponse({ ok: true });
          return true;
        }
        if (message.type === "TOGGLE_AUTO_TRANSLATE") {
          chrome.storage.local.set({ autoTranslate: message.enabled }, () => {
            sendResponse({ ok: true });
          });
          return true;
        }
        if (message.type === "CHANGE_STYLE") {
          chrome.storage.local.set({ translationStyle: message.style }, () => {
            sendResponse({ ok: true });
          });
          return true;
        }
        return false;
      }
    );
  }
})();
