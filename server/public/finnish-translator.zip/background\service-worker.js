"use strict";
(() => {
  // src/background/api-client.ts
  var DEFAULT_PROXY_URL = "https://finntalk-webtranslate-production.up.railway.app";
  var ApiClient = class {
    constructor(proxyUrl = DEFAULT_PROXY_URL, model) {
      this.proxyUrl = proxyUrl || DEFAULT_PROXY_URL;
      this.model = model;
    }
    async detectTopic(text) {
      const response = await fetch(`${this.proxyUrl}/api/detect-topic`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, model: this.model })
      });
      if (!response.ok) {
        const error = new Error(`HTTP error ${response.status}`);
        error.code = response.status;
        throw error;
      }
      const data = await response.json();
      return data.choices[0].message.content;
    }
    async translateBlock(block, systemPrompt) {
      const response = await fetch(`${this.proxyUrl}/api/translate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: block, systemPrompt, model: this.model })
      });
      if (!response.ok) {
        const error = new Error(`HTTP error ${response.status}`);
        error.code = response.status;
        throw error;
      }
      const data = await response.json();
      return data.choices[0].message.content;
    }
    async qualityCheck(original, translated) {
      const response = await fetch(`${this.proxyUrl}/api/quality-check`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ original, translated, model: this.model })
      });
      if (!response.ok) {
        const error = new Error(`HTTP error ${response.status}`);
        error.code = response.status;
        throw error;
      }
      const data = await response.json();
      return data.choices[0].message.content;
    }
  };

  // src/background/queue.ts
  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  var RequestQueue = class {
    constructor() {
      this._paused = false;
      this._pauseUntil = 0;
    }
    async enqueue(request) {
      if (this._paused) {
        const remaining = this._pauseUntil - Date.now();
        if (remaining > 0) {
          await delay(remaining);
        }
        this._paused = false;
      }
      const delays = [1e3, 2e3, 4e3];
      let lastError;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          return await request();
        } catch (err) {
          lastError = err;
          if (err && err.code === 401) {
            throw err;
          }
          if (err && err.code === 429) {
            this.pause(6e4);
            await delay(6e4);
          } else {
            if (attempt < delays.length) {
              await delay(delays[attempt]);
            }
          }
        }
      }
      throw lastError;
    }
    pause(durationMs) {
      this._paused = true;
      this._pauseUntil = Date.now() + durationMs;
    }
    getStatus() {
      if (!this._paused) {
        return { paused: false, pauseRemainingMs: 0 };
      }
      const remaining = this._pauseUntil - Date.now();
      if (remaining <= 0) {
        this._paused = false;
        return { paused: false, pauseRemainingMs: 0 };
      }
      return { paused: true, pauseRemainingMs: remaining };
    }
  };

  // src/background/service-worker.ts
  var PROXY_URL = "https://finntalk-webtranslate-production.up.railway.app";
  var SYSTEM_PROMPT = "\u0422\u044B \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A \u0441 \u0444\u0438\u043D\u0441\u043A\u043E\u0433\u043E \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u0438\u0439 \u044F\u0437\u044B\u043A. \u041F\u0435\u0440\u0435\u0432\u043E\u0434\u0438 \u0442\u043E\u0447\u043D\u043E \u0438 \u0435\u0441\u0442\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u043E. \u0412\u0410\u0416\u041D\u041E: \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0439 \u0422\u041E\u041B\u042C\u041A\u041E \u0447\u0438\u0441\u0442\u044B\u0439 \u0442\u0435\u043A\u0441\u0442 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430 \u0431\u0435\u0437 \u043A\u0430\u043A\u043E\u0433\u043E-\u043B\u0438\u0431\u043E \u0444\u043E\u0440\u043C\u0430\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F, \u0431\u0435\u0437 Markdown, \u0431\u0435\u0437 \u0437\u0432\u0451\u0437\u0434\u043E\u0447\u0435\u043A, \u0431\u0435\u0437 \u0440\u0435\u0448\u0451\u0442\u043E\u043A, \u0431\u0435\u0437 \u0442\u0438\u0440\u0435 \u0432 \u043D\u0430\u0447\u0430\u043B\u0435 \u0441\u0442\u0440\u043E\u043A, \u0431\u0435\u0437 HTML-\u0442\u0435\u0433\u043E\u0432. \u041A\u0430\u0436\u0434\u0443\u044E \u0441\u0442\u0440\u043E\u043A\u0443 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u0430 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0438 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u043E\u0439 \u0432 \u0442\u043E\u043C \u0436\u0435 \u043F\u043E\u0440\u044F\u0434\u043A\u0435.";
  var CHUNK_SIZE = 3e3;
  var queue = new RequestQueue();
  function log(...a) {
    console.log("[FT]", ...a);
  }
  function logErr(...a) {
    console.error("[FT ERR]", ...a);
  }
  async function getSettings() {
    return new Promise((r) => chrome.storage.local.get({
      proxyUrl: PROXY_URL,
      model: "gpt-4o-mini",
      requestsPerMinute: 20,
      qualityCheckEnabled: false,
      translationStyle: "\u043D\u0435\u0439\u0442\u0440\u0430\u043B\u044C\u043D\u044B\u0439",
      autoTranslate: false
    }, (s) => r(s)));
  }
  function splitIntoChunks(text, size) {
    const chunks = [];
    const lines = text.split("\n");
    let current = "";
    for (const line of lines) {
      if (current.length + line.length + 1 > size && current.length > 0) {
        chunks.push(current);
        current = line;
      } else {
        current = current ? current + "\n" + line : line;
      }
    }
    if (current) chunks.push(current);
    return chunks;
  }
  async function translateChunk(text, model) {
    const client = new ApiClient(PROXY_URL, model);
    const raw = await queue.enqueue(() => client.translateBlock(text, SYSTEM_PROMPT));
    return raw.replace(/\*\*(.*?)\*\*/g, "$1").replace(/\*(.*?)\*/g, "$1").replace(/^#{1,6}\s+/gm, "").replace(/^[-*+]\s+/gm, "").replace(/`{1,3}(.*?)`{1,3}/g, "$1").trim();
  }
  async function handleTranslatePage(tabId) {
    log("translate tab", tabId);
    const settings = await getSettings();
    let rawText;
    let blocks;
    try {
      const res = await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, { type: "EXTRACT_TEXT" }, (r) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else if (!r) reject(new Error("no response"));
          else resolve(r);
        });
      });
      rawText = res.rawText;
      blocks = res.blocks;
      log("extracted chars=", rawText.length);
    } catch (e) {
      logErr("EXTRACT_TEXT:", e.message);
      chrome.runtime.sendMessage({ type: "TRANSLATION_ERROR", message: "\u041F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 (F5) \u0438 \u043F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0441\u043D\u043E\u0432\u0430." });
      return;
    }
    if (!rawText || rawText.trim().length < 5) {
      chrome.runtime.sendMessage({ type: "TRANSLATION_ERROR", message: "\u0422\u0435\u043A\u0441\u0442 \u0434\u043B\u044F \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D." });
      return;
    }
    const chunks = splitIntoChunks(rawText, CHUNK_SIZE);
    log("chunks=", chunks.length);
    chrome.runtime.sendMessage({ type: "PROGRESS_UPDATE", done: 0, total: chunks.length, topic: "\u0431\u044B\u0442\u043E\u0432\u0430\u044F" });
    let translatedChunks;
    try {
      translatedChunks = await Promise.all(
        chunks.map(
          (chunk, i) => translateChunk(chunk, settings.model).then((t) => {
            chrome.runtime.sendMessage({ type: "PROGRESS_UPDATE", done: i + 1, total: chunks.length, topic: "\u0431\u044B\u0442\u043E\u0432\u0430\u044F" });
            return t;
          })
        )
      );
      log("all chunks translated");
    } catch (e) {
      logErr("translate:", e.message, "code=", e.code);
      const msg = e.code === 401 ? "\u041E\u0448\u0438\u0431\u043A\u0430 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u0438. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 OPENAI_API_KEY \u043D\u0430 Railway." : e.code === 429 ? "\u041F\u0440\u0435\u0432\u044B\u0448\u0435\u043D \u043B\u0438\u043C\u0438\u0442 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432." : `\u041E\u0448\u0438\u0431\u043A\u0430: ${e.message}`;
      chrome.runtime.sendMessage({ type: "TRANSLATION_ERROR", message: msg, openOptions: e.code === 401 });
      return;
    }
    const fullTranslation = translatedChunks.join("\n");
    try {
      await new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, { type: "APPLY_TRANSLATION", translatedParts: [fullTranslation] }, (r) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else {
            log("applied:", r);
            resolve();
          }
        });
      });
    } catch (e) {
      logErr("APPLY_TRANSLATION:", e.message);
      chrome.runtime.sendMessage({ type: "TRANSLATION_ERROR", message: "\u041F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 (F5) \u0438 \u043F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0441\u043D\u043E\u0432\u0430." });
    }
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    log("msg:", msg.type);
    if (msg.type === "TRANSLATE_PAGE") {
      handleTranslatePage(msg.tabId).catch((e) => logErr("unhandled:", e));
      sendResponse({ ok: true });
      return true;
    }
    if (msg.type === "TRANSLATE_VISIBLE") {
      getSettings().then((s) => translateChunk(msg.text, s.model)).then((t) => sendResponse({ translatedText: t })).catch((e) => {
        logErr("TRANSLATE_VISIBLE:", e);
        sendResponse({ translatedText: null });
      });
      return true;
    }
    if (msg.type === "TOGGLE_AUTO_TRANSLATE") {
      chrome.storage.local.set({ autoTranslate: msg.enabled }, () => sendResponse({ ok: true }));
      return true;
    }
    if (msg.type === "CHANGE_STYLE") {
      chrome.storage.local.set({ translationStyle: msg.style }, () => sendResponse({ ok: true }));
      return true;
    }
    return false;
  });
  log("loaded");
})();
