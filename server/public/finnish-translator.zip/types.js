// Типы и интерфейсы для расширения Finnish-to-Russian Translator
export {};
