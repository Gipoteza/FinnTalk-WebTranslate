"use strict";
(() => {
  // src/popup/popup.ts
  var showingOriginal = false;
  function show(el) {
    el?.classList.remove("hidden");
  }
  function hide(el) {
    el?.classList.add("hidden");
  }
  async function init() {
    const btnTranslate = document.getElementById("btn-translate");
    const btnAutoTranslate = document.getElementById("btn-auto-translate");
    const btnShowOriginal = document.getElementById("btn-show-original");
    const progressEl = document.getElementById("progress");
    const progressText = document.getElementById("progress-text");
    const errorMessage = document.getElementById("error-message");
    const errorText = document.getElementById("error-text");
    const openSettings = document.getElementById("open-settings");
    const settings = await chrome.storage.local.get(["autoTranslate"]);
    if (settings.autoTranslate) {
      btnAutoTranslate.classList.add("active");
    }
    btnTranslate.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id == null) return;
      chrome.runtime.sendMessage({ type: "TRANSLATE_PAGE", tabId: tab.id });
      show(progressEl);
      progressText.textContent = "0 / ?";
      hide(errorMessage);
    });
    btnAutoTranslate.addEventListener("click", () => {
      const enabled = !btnAutoTranslate.classList.contains("active");
      if (enabled) {
        btnAutoTranslate.classList.add("active");
      } else {
        btnAutoTranslate.classList.remove("active");
      }
      chrome.runtime.sendMessage({ type: "TOGGLE_AUTO_TRANSLATE", enabled });
    });
    btnShowOriginal.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id == null) return;
      if (!showingOriginal) {
        chrome.tabs.sendMessage(tab.id, { type: "RESTORE_ORIGINAL" });
        btnShowOriginal.textContent = "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u0435\u0440\u0435\u0432\u043E\u0434";
        showingOriginal = true;
      } else {
        chrome.tabs.sendMessage(tab.id, { type: "SHOW_TRANSLATION" });
        btnShowOriginal.textContent = "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B";
        showingOriginal = false;
      }
    });
    openSettings.addEventListener("click", (e) => {
      e.preventDefault();
      chrome.runtime.openOptionsPage();
    });
    chrome.runtime.onMessage.addListener((message) => {
      if (message.type === "PROGRESS_UPDATE") {
        const { done, total } = message;
        show(progressEl);
        progressText.textContent = `${done} / ${total}`;
      }
      if (message.type === "TRANSLATION_ERROR") {
        const { message: msg, openOptions } = message;
        errorText.textContent = msg;
        show(errorMessage);
        if (openOptions) {
          show(openSettings);
        } else {
          hide(openSettings);
        }
      }
    });
  }
  document.addEventListener("DOMContentLoaded", init);
})();
