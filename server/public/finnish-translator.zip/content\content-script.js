"use strict";
(() => {
  // src/content/content-script.ts
  var originalHTML = null;
  var translatedHTML = null;
  var translatedBlocks = /* @__PURE__ */ new Map();
  var allBlocks = [];
  function splitIntoBlocks(text) {
    if (text.length === 0) return [];
    const breakRegex = /[.!?](?=\s|$)/g;
    const breakPositions = [];
    let m;
    while ((m = breakRegex.exec(text)) !== null) breakPositions.push(m.index + m[0].length);
    const sentences = [];
    let pos = 0;
    for (const bp of breakPositions) {
      if (bp > pos) {
        sentences.push(text.slice(pos, bp));
        pos = bp;
      }
    }
    if (pos < text.length) sentences.push(text.slice(pos));
    if (sentences.length === 0) return [{ id: crypto.randomUUID(), text, nodeIds: [] }];
    const blocks = [];
    let current = "";
    for (const sentence of sentences) {
      current += sentence;
      if (current.length >= 2e3) {
        blocks.push({ id: crypto.randomUUID(), text: current, nodeIds: [] });
        current = "";
      }
    }
    if (current.length > 0) blocks.push({ id: crypto.randomUUID(), text: current, nodeIds: [] });
    return blocks;
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "EXTRACT_TEXT") {
      originalHTML = document.body.innerHTML;
      translatedHTML = null;
      translatedBlocks.clear();
      const rawText = document.body.innerText;
      allBlocks = splitIntoBlocks(rawText);
      sendResponse({ rawText, blocks: allBlocks });
    } else if (message.type === "REPLACE_BLOCK") {
      translatedBlocks.set(message.blockId, message.text);
      if (allBlocks.length > 0 && translatedBlocks.size >= allBlocks.length) {
        const fullText = allBlocks.map((b) => translatedBlocks.get(b.id) ?? b.text).join("\n\n");
        replacePageText(fullText);
      }
    } else if (message.type === "RESTORE_ORIGINAL") {
      if (originalHTML !== null) {
        translatedHTML = document.body.innerHTML;
        document.body.innerHTML = originalHTML;
      }
    } else if (message.type === "SHOW_TRANSLATION") {
      if (translatedHTML !== null) document.body.innerHTML = translatedHTML;
    }
    return true;
  });
  function replacePageText(translatedText) {
    if (!originalHTML) return;
    const temp = document.createElement("div");
    temp.innerHTML = originalHTML;
    const parts = translatedText.split(/\n+/).filter((s) => s.trim().length > 0);
    let idx = 0;
    const walker = document.createTreeWalker(temp, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode()) && idx < parts.length) {
      if ((node.nodeValue?.trim().length ?? 0) >= 3) node.nodeValue = parts[idx++];
    }
    translatedHTML = temp.innerHTML;
    document.body.innerHTML = translatedHTML;
  }
})();
