"use strict";
(() => {
  // src/content/content-script.ts
  function splitIntoBlocks(text) {
    if (text.length === 0) {
      return [];
    }
    const breakRegex = /[.!?…](?=\s|$)/g;
    const breakPositions = [];
    let m;
    while ((m = breakRegex.exec(text)) !== null) {
      breakPositions.push(m.index + m[0].length);
    }
    const sentences = [];
    let pos = 0;
    for (const bp of breakPositions) {
      if (bp > pos) {
        sentences.push(text.slice(pos, bp));
        pos = bp;
      }
    }
    if (pos < text.length) {
      sentences.push(text.slice(pos));
    }
    if (sentences.length === 0) {
      return [{ id: crypto.randomUUID(), text, nodeIds: [] }];
    }
    const blocks = [];
    let current = "";
    for (const sentence of sentences) {
      current += sentence;
      if (current.length >= 2e3) {
        blocks.push({ id: crypto.randomUUID(), text: current, nodeIds: [] });
        current = "";
      }
    }
    if (current.length > 0) {
      blocks.push({ id: crypto.randomUUID(), text: current, nodeIds: [] });
    }
    return blocks;
  }
})();
