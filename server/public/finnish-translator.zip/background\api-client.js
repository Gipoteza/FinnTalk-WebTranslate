// Модуль взаимодействия с Railway Proxy Server
// Все запросы направляются к proxyUrl (Railway), а не напрямую к OpenAI
// URL прокси-сервера зашит в расширение
const DEFAULT_PROXY_URL = 'https://finntalk-webtranslate-production.up.railway.app';
export class ApiClient {
    constructor(proxyUrl = DEFAULT_PROXY_URL, model) {
        this.proxyUrl = proxyUrl || DEFAULT_PROXY_URL;
        this.model = model;
    }
    async detectTopic(text) {
        const response = await fetch(`${this.proxyUrl}/api/detect-topic`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text, model: this.model }),
        });
        if (!response.ok) {
            const error = new Error(`HTTP error ${response.status}`);
            error.code = response.status;
            throw error;
        }
        const data = await response.json();
        return data.choices[0].message.content;
    }
    async translateBlock(block, systemPrompt) {
        const response = await fetch(`${this.proxyUrl}/api/translate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: block, systemPrompt, model: this.model }),
        });
        if (!response.ok) {
            const error = new Error(`HTTP error ${response.status}`);
            error.code = response.status;
            throw error;
        }
        const data = await response.json();
        return data.choices[0].message.content;
    }
    async qualityCheck(original, translated) {
        const response = await fetch(`${this.proxyUrl}/api/quality-check`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ original, translated, model: this.model }),
        });
        if (!response.ok) {
            const error = new Error(`HTTP error ${response.status}`);
            error.code = response.status;
            throw error;
        }
        const data = await response.json();
        return data.choices[0].message.content;
    }
}
